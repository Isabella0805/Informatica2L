let b = parseFloat(prompt("Ingrese un numero"))
if (b==0){ 
alert("b es cero")
}

