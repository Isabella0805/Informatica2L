let total = 0;
let sumando = 0;
while (sumando <= 10000)
{
    total = total + sumando;
    sumando = sumando + 3;
}
console.log (total);