let total = 0;
let sumando = 0;
while (sumando <= 10000)
{
    total = total + sumando;
    sumando = sumando + 5;
}
console.log (`resultado: ${total}`);