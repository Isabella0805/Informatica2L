let total = 0;
let sumando = 0;
while (sumando <= 10000)
{
    if()
}
console.log (total);